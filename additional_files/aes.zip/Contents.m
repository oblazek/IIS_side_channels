% AES
%
% Files
%   aes             - Encrypt/decrypt array of bytes by AES.
%   AES_GET_COUNTER - Generates counter for aes.m - an example.
%   aesdecrypt      - Decrypt 16-bytes vector.
%   aesencrypt      - Encrypt 16-bytes vector.
%   aesinfo         - Display info about AES setting in AES structure.
%   aesinit         - Generate structure with s-boxes, expanded key, etc.
%   aestest         - AES test script.
